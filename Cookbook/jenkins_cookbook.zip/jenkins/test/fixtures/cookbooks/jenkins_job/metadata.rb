name 'jenkins_job'
depends 'jenkins_server_wrapper'

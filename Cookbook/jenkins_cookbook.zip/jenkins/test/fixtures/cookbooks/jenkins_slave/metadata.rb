name 'jenkins_slave'
depends 'jenkins_server_wrapper'

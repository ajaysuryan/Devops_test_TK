name 'jenkins_user'
depends 'jenkins_server_wrapper'

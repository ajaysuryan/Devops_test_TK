name 'jenkins_server_wrapper'
depends 'java', '>= 7' # 7.0 adds the javadoptopenjdk_install resource
depends 'jenkins'

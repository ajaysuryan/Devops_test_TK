name 'jenkins_proxy'
depends 'jenkins_server_wrapper'

name 'jenkins_command'
depends 'jenkins_server_wrapper'

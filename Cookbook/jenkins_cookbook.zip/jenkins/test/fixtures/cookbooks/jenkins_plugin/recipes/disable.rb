# Test pluging disable
jenkins_plugin 'ansicolor' do
  action :disable
end

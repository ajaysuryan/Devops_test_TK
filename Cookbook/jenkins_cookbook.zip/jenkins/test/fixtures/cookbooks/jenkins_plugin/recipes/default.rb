include_recipe '::install'
include_recipe '::disable'
include_recipe '::enable'
include_recipe '::uninstall'

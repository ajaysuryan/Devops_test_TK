# encoding: utf-8
# copyright: 2018, The Authors

title 'Test all the Jenkins things'

include_controls 'jenkins_smoke'
